﻿'use strict';

var Wingtip = window.Wingtip || {};

$(document).ready(function () {
    if (Wingtip.Converter.init() === true) {
        Wingtip.Converter.execute().then(
            function (data) {

                var destUrl = $.parseJSON(data.$C_1).Destination;
                var sourceUrl = $.parseJSON(data.$C_1).Source;

                $("#messages").html("Conversion job is initiated. The job may take several minutes to complete.");
                $("#source").html("Source File Location: <a href='" + sourceUrl + "'>" + sourceUrl + "</a>");
                $("#destination").html("Converted File Location: <a href='" + destUrl + "'>" + destUrl + "</a>");

            },
            function (err) {
                $("#messages").html(JSON.stringify(err));
            }
        );
    }
    else {
        $("#messages").html("Please use the menu item associated with a Word document to access this app.");
    }
});

Wingtip.Converter = function () {

    var serviceLocation = "http://localhost:7000/_api/was",
        siteUrl,
        listId,
        itemId,
        jsonObject,

        init = function () {

            siteUrl = queryString("SiteUrl");
            listId = queryString("ListId");
            itemId = queryString("ItemId");
            if (siteUrl.length === 0 || listId.length === 0 || itemId.length === 0) {
                return false;
            }
            else {
                return true;
            }

        },

        execute = function () {

            this.deferred = $.Deferred();

            var ctx = SP.ClientContext.get_current();
            var request = new SP.WebRequestInfo();
            request.set_url(serviceLocation + "?SiteUrl=" + siteUrl + "&ListId=" + listId + "&ItemId=" + itemId);
            request.set_method("GET");
            request.set_headers("accept:application/json");
            this.jsonObject = SP.WebProxy.invoke(ctx, request);
            ctx.executeQueryAsync(
                Function.createDelegate(this,
                    function () { this.deferred.resolve(this.jsonObject); }),
                Function.createDelegate(this,
                    function (err) { this.deferred.reject(err); }));

            return this.deferred.promise();

        },

        queryString = function (name) {

            try {
                var args = window.location.search.substring(1).split("&");
                var r = "";
                for (var i = 0; i < args.length; i++) {
                    var n = args[i].split("=");
                    if (n[0] == name)
                        r = decodeURIComponent(n[1]);
                }
                return r;
            }
            catch (err) {
                return 'undefined';
            }

        };

    return {
        init: init,
        execute: execute
    };

}();

