﻿using System;
using System.Security.Principal;
using System.Web;
using System.IO;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Administration;
using Microsoft.SharePoint.Security;
using Microsoft.Office.Word.Server.Conversions;
using WASREST.Models;

namespace WASREST.Controllers
{
    public class WASController : ApiController
    {
        public WASResponse Get(string SiteUrl, string ListId, string ItemId)
        {
            WASResponse wasResponse = new WASResponse();

            try
            {
                string wordFile = string.Empty;
                string pdfFile = string.Empty;

                using (WindowsIdentity.GetCurrent().Impersonate())
                {
                    SPSecurity.RunWithElevatedPrivileges(delegate()
                    {
                        using (SPSite site = new SPSite(SiteUrl))
                        {
                            using (SPWeb web = site.OpenWeb())
                            {
                                SPDocumentLibrary library =
                                  (SPDocumentLibrary)web.Lists[new Guid(ListId)];
                                SPListItem item = library.GetItemById(int.Parse(ItemId));
                                SPFile file = item.File;

                                if (file.Name.EndsWith(".doc",
                                    StringComparison.CurrentCultureIgnoreCase) ||
                                    file.Name.EndsWith(".docx",
                                    StringComparison.CurrentCultureIgnoreCase))
                                {
                                    //Set up the job
                                    ConversionJobSettings jobSettings = new ConversionJobSettings();
                                    jobSettings.OutputFormat = SaveFormat.PDF;
                                    ConversionJob job =
                                      new ConversionJob("Word Automation Services", jobSettings);
                                    job.UserToken = site.SystemAccount.UserToken;

                                    //File names
                                    wordFile = web.Url + "/" + item.Url;
                                    pdfFile = string.Empty;
                                    if (file.Name.EndsWith(".doc",
                                        StringComparison.CurrentCultureIgnoreCase))
                                        pdfFile = wordFile.Replace(".doc", ".pdf");
                                    if (file.Name.EndsWith(".docx",
                                        StringComparison.CurrentCultureIgnoreCase))
                                        pdfFile = wordFile.Replace(".docx", ".pdf");

                                    //Start Job
                                    job.AddFile(wordFile, pdfFile);
                                    job.Start();

                                }
                            }
                        }
                    });
                }

                //Success
                wasResponse.Message = "Success";
                wasResponse.Source = wordFile;
                wasResponse.Destination = pdfFile;

            }
            catch (Exception x)
            {
                //Failure
                wasResponse.Message = x.Message;
            }

            return wasResponse;
        }

    }
}
