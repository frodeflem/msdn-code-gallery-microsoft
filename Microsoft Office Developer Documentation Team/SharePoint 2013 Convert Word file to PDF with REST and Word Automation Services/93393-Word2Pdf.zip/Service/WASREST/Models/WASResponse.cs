﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WASREST.Models
{
    public class WASResponse
    {
        public string Message { get; set; }
        public string Source { get; set; }
        public string Destination { get; set; }
    }
}